from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        role = request.form['role']
        if role == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))
    return render_template('login.html')

@app.route('/admin')
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/user')
def user_dashboard():
    return render_template('user_dashboard.html')

@app.route('/books')
def books():
    return render_template('books.html')

@app.route('/users')
def users():
    return "<h2>View Users Page (Coming Soon)</h2>"

@app.route('/reports')
def reports():
    return "<h2>Reports Page (Coming Soon)</h2>"

@app.route('/issue')
def issue_book():
    return "<h2>Issue Book Page (Coming Soon)</h2>"

@app.route('/return')
def return_book():
    return "<h2>Return Book Page (Coming Soon)</h2>"

@app.route('/logout')
def logout():
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)


from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'change_this_to_a_secret_key'

# ———— In‑memory “DB” for demo ————
# (Replace these with real database calls later)
books = []
users = [{'id': 1, 'username': 'alice', 'role': 'user'},
         {'id': 2, 'username': 'bob',   'role': 'user'},
         {'id': 3, 'username': 'admin', 'role': 'admin'}]
issues = []

def find_book(bid):
    return next((b for b in books if b['id']==bid), None)

def find_user(uid):
    return next((u for u in users if u['id']==uid), None)

def next_id(coll):
    return max([item['id'] for item in coll], default=0) + 1

# ———— Routes ————

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        username = request.form['username']
        role     = request.form['role']
        # find user or auto‑create
        user = next((u for u in users if u['username']==username and u['role']==role), None)
        if not user:
            flash('Invalid credentials', 'error')
            return redirect(url_for('login'))
        if role=='admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    return redirect(url_for('home'))

@app.route('/admin')
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/user')
def user_dashboard():
    return render_template('user_dashboard.html')


# ———— Books ————

@app.route('/books', methods=['GET','POST'])
def manage_books():
    if request.method=='POST':
        title  = request.form['title']
        author = request.form['author']
        books.append({
            'id':     next_id(books),
            'title':  title,
            'author': author,
            'available': True
        })
        flash('Book added', 'success')
        return redirect(url_for('manage_books'))
    return render_template('books.html', books=books)


# ———— Users ————

@app.route('/users')
def view_users():
    return render_template('users.html', users=users)


# ———— Reports ————

@app.route('/reports')
def reports():
    total_books  = len(books)
    issued_books = len([i for i in issues if not i.get('returned')])
    overdue      = len([
        i for i in issues
        if not i.get('returned') and i['due_date'] < datetime.utcnow().date()
    ])
    return render_template('reports.html',
                           total_books=total_books,
                           issued_books=issued_books,
                           overdue=overdue)


# ———— Issue Book ————

@app.route('/issue', methods=['GET','POST'])
def issue_book():
    if request.method=='POST':
        user_id = int(request.form['user_id'])
        book_id = int(request.form['book_id'])
        book = find_book(book_id)
        if not book or not book['available']:
            flash('Book not available', 'error')
        else:
            issue_record = {
                'id':        next_id(issues),
                'user_id':   user_id,
                'book_id':   book_id,
                'issue_date': datetime.utcnow().date(),
                'due_date':   datetime.utcnow().date() + timedelta(days=14),
                'returned':  False
            }
            issues.append(issue_record)
            book['available'] = False
            flash('Book issued', 'success')
        return redirect(url_for('issue_book'))

    available_books = [b for b in books if b['available']]
    return render_template('issue.html',
                           users=users,
                           books=available_books,
                           issues=[i for i in issues if not i['returned']])


# ———— Return Book ————

@app.route('/return', methods=['GET','POST'])
def return_book():
    if request.method=='POST':
        issue_id = int(request.form['issue_id'])
        issue_rec = next((i for i in issues if i['id']==issue_id), None)
        if issue_rec and not issue_rec['returned']:
            issue_rec['returned']    = True
            issue_rec['return_date'] = datetime.utcnow().date()
            # calculate fine
            if issue_rec['return_date'] > issue_rec['due_date']:
                days_over = (issue_rec['return_date'] - issue_rec['due_date']).days
                issue_rec['fine'] = days_over * 1.0
            # mark book available
            book = find_book(issue_rec['book_id'])
            if book:
                book['available'] = True
            flash('Book returned', 'success')
        return redirect(url_for('return_book'))

    pending_issues = [i for i in issues if not i['returned']]
    return render_template('return.html', issues=pending_issues)


if __name__ == '__main__':
    app.run(debug=True)
