if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Dummy login validation
        if username == 'admin' and password == 'admin':
            return redirect(url_for('dashboard'))
        else: