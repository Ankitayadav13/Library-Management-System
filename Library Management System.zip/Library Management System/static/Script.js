document.addEventListener("DOMContentLoaded", () => {
  // 1. Login form validation
  const loginForm = document.querySelector("form[action='/login']");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      const username = document.getElementById("username").value.trim();
      if (username === "") {
        e.preventDefault();
        alert("Please enter your username before logging in.");
      }
    });
  }

  // 2. Confirm before logging out
  const logoutLinks = document.querySelectorAll("a[href='/logout']");
  logoutLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      if (!confirm("Are you sure you want to log out?")) {
        e.preventDefault();
      }
    });
  });

  // 3. Highlight active navigation link (optional)
  const currentPath = window.location.pathname;
  document.querySelectorAll("a").forEach((link) => {
    if (link.getAttribute("href") === currentPath) {
      link.style.fontWeight = "bold";
    }
  });
});
