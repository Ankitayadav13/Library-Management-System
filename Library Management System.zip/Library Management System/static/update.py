from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

books_db = [
    {"id": 1, "title": "1984", "author": "George Orwell", "status": "Available"},
    {"id": 2, "title": "The Hobbit", "author": "J.R.R. Tolkien", "status": "Issued"},
    {"id": 3, "title": "To Kill a Mockingbird", "author": "Harper Lee", "status": "Available"}
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'admin':
            return redirect(url_for('dashboard'))
        else:
            return "Login Failed"
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/books')
def books():
    return render_template('books.html', books=books_db)

@app.route('/add-book', methods=['GET', 'POST'])
def add_book():
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        new_id = max(book['id'] for book in books_db) + 1
        books_db.append({"id": new_id, "title": title, "author": author, "status": "Available"})
        return redirect(url_for('books'))
    return render_template('add_book.html')

@app.route('/issue-return', methods=['GET', 'POST'])
def issue_return():
    if request.method == 'POST':
        book_id = int(request.form['book_id'])
        action = request.form['action']
        for book in books_db:
            if book['id'] == book_id:
                if action == 'issue' and book['status'] == 'Available':
                    book['status'] = 'Issued'
                elif action == 'return' and book['status'] == 'Issued':
                    book['status'] = 'Available'
                break
        return redirect(url_for('books'))
    return render_template('issue_return.html')

@app.route('/logout')
def logout():
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
